import beans.*;
import facade.AdminFacade;
import facade.CompanyFacade;
import facade.CustomerFacade;
import facade.LoginManager;
import utils.TablePrinter;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Scanner;

public class test {
    public static void testAll() throws Exception {

/*      _______________    M e n u    _____________________*/
        System.out.print(">>> Facades : ");
        int bound = Category.values().length - 1;
        for (int i = 1; i <= bound; i++) {
            ClientType clientTypeByIndex = ClientType.getClientTypeByIndex(i);
            System.out.print(i + "=" + clientTypeByIndex + "\t" + "  ");
        }
        System.out.print("\n>>> Choice you Facade number >");
        Scanner scanner = new Scanner(System.in);
        ClientType clientType = ClientType.getClientTypeByIndex(scanner.nextInt());
        LoginManager loginManager = LoginManager.getInstance();

        switch (clientType) {
            case Administrator: {
                testAdminFacade();
            }
            break;
            case Company: {
                  testCompanyFacade();
            }
            break;
            case Customer: {
                testCustomerFacade();
                 }
            break;

            default:
                System.out.println("  You choice is wrong! ");
        }
        System.out.println("");
    }


 /*       @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//*       @@          TEST         A D M I N          FACADE                                @@
//*       @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ */
    public static void testAdminFacade() throws Exception {
        LoginManager loginManager = LoginManager.getInstance();
        String password = "admin";
        String email = "admin@admin.com";
        AdminFacade adminFacade = (AdminFacade) loginManager.login(email,password, ClientType.valueOf("Administrator"));

        TablePrinter.print(adminFacade.getAllCustomers());
        Customer c1 = new Customer("Max", "Chokolatier", "choklatier@mail.ru", "23456");
        adminFacade.addCustomer(c1);
        TablePrinter.print(adminFacade.getAllCustomers());

        System.out.println(" >>    adminFacade.getOneCustomer ");
        Customer c2 = adminFacade.getOneCustomer(2);

        System.out.println(" >>    adminFacade.updateCustomer " + c2);
        c2.setLastName("updated LASTNAME");
        adminFacade.updateCustomer(c2);
        TablePrinter.print(adminFacade.getAllCustomers());
        System.out.println(" >>    adminFacade.deleteCustomer " + c2);
        adminFacade.deleteCustomer(11);
        TablePrinter.print(adminFacade.getAllCustomers());
//--------------------------------------------------------------
        System.out.println(" >>    adminFacade.getAllCompanies ");
        TablePrinter.print(adminFacade.getAllCompanies());
        Company company1 = new Company("   Maxy Brenner", "MaxyBrenner@gmail.com", "12345");
        System.out.println(" >>    adminFacade.addCompany ");
        adminFacade.addCompany(company1);
        TablePrinter.print(adminFacade.getAllCompanies());
//----------
        Company company2 = adminFacade.getOneCompany(2);
        System.out.println(" >>    adminFacade.updateCompany " + company2);
        company2.setPassword("updated PASSWORD");
        adminFacade.updateCompany(company2);
        TablePrinter.print(adminFacade.getAllCompanies());
        System.out.println(" >>    adminFacade.deleteCompany = 2  ");
        adminFacade.deleteCompany(company2);
        TablePrinter.print(adminFacade.getAllCompanies());

    }
   /*      @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
   *       @@          TEST          C O M P A N Y          FACADE                           @@
   *       @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
   */
    public static void testCompanyFacade() throws Exception {
        String password = "1234";
        String email = "nike@gmail.com";
        LoginManager loginManager = LoginManager.getInstance();
        CompanyFacade companyFacade = (CompanyFacade) loginManager.login(email, password, ClientType.getClientTypeByIndex(2));
      //  Company company1 = companyFacade.getCompanyNameByEmailPass(email,password);
        Company company1 = companyFacade.getCompanyDetails();
        System.out.println("=============================================================");
        System.out.println("    Hello autorized  company  !" + company1.toString() );

        TablePrinter.print(companyFacade.getCompanyCoupons());

        System.out.println(" all coupons of company " + companyFacade.getCompanyId() + "by Category Vacatiov  "  );
        TablePrinter.print(companyFacade.getCompanyCouponsByCategory(Category.Vacation));

        System.out.println(" all coupons of company " + companyFacade.getCompanyId() + " under price 900.99 "  );
        TablePrinter.print(companyFacade.getCompanyCouponsUnderPrice((double)900.99));

//-------------------------------------   add  coupon of company------------
        Coupon wrongcoupon1 = new Coupon(1, Category.Food, "test add coupon", "1+1",
                Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf(LocalDate.now().plusWeeks(1)), 5, 1.2, "no Image ");
        System.out.println(" add wrong coupon of COMPANY=1 to current company " + companyFacade.getCompanyId()    );
         companyFacade.addCoupon(wrongcoupon1);
        System.out.println("");
        TablePrinter.print(companyFacade.getCompanyCoupons());

        Coupon rightcoupon = new Coupon(companyFacade.getCompanyId(),Category.Food, "test add coupon", "1+1",
                Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf(LocalDate.now().plusWeeks(1)), 5, 1.2, "no Image ");
        System.out.println(" add right new coupon of current company= " + companyFacade.getCompanyId() + ')' );
        companyFacade.addCoupon(rightcoupon);
        System.out.println("");
        TablePrinter.print(companyFacade.getCompanyCoupons());

        Coupon wrongcouponTitle = new Coupon(companyFacade.getCompanyId(), Category.Food, "test add coupon", "1+1",
                Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf(LocalDate.now().plusWeeks(1)), 5, 1.2, "no Image ");
        System.out.println(" add TITLE wrong coupon of company 5 to current company " + companyFacade.getCompanyId()    );
        companyFacade.addCoupon(wrongcouponTitle);
        System.out.println("");
        TablePrinter.print(companyFacade.getCompanyCoupons());

        Coupon rightcoupon1 = new Coupon(5, Category.Food, "test", "Sale in Foods",
                Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf(LocalDate.now().plusWeeks(1)), 5, 1.2, "no Image ");
        System.out.println(" add right new coupon of current company= " + companyFacade.getCompanyId() + ')' );
        companyFacade.addCoupon(rightcoupon1);
        System.out.println("");
        TablePrinter.print(companyFacade.getCompanyCoupons());

//--------------------------------      update coupons of company--------------
      //  System.out.println(" >>    companyFacade.getOneCouponOfCompany " +  companyFacade.getCompanyId());
      //   Coupon fetchedCoupon = companyFacade.getOneCompanyCopupon();
        System.out.println(" >>start    companyFacade.updateCoupon ");
        Coupon updatedCoupon = new Coupon();
        updatedCoupon = companyFacade.getOneCompanyCouponByTitle(5,"test");
        System.out.println(" >>      companyFacade.updateCoupon of company " + updatedCoupon);
        updatedCoupon.setDescription("updated Description");
        companyFacade.updateCoupon(updatedCoupon);
        System.out.println("");
        TablePrinter.print(companyFacade.getCompanyCoupons());

//--------------------------------      delete ONE coupon of  company--------------
        System.out.println(" >>start    companyFacade.updateCoupon ----------");
        System.out.println(" >>      companyFacade.delete ONE coupon of WRONG COMPANY = 1 !)"  );
        System.out.println("");
        TablePrinter.print(companyFacade.getCompanyCoupons());
        companyFacade.deleteCoupon(1);
        System.out.println("");
        TablePrinter.print(companyFacade.getCompanyCoupons());

        System.out.println(" >>      companyFacade.delete ONE coupon=10  of right company 5 "  );
        companyFacade.deleteCoupon(10);
        System.out.println("");
        TablePrinter.print(companyFacade.getCompanyCoupons());
    }




/*      @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
*       @@          TEST          CUSTOMER         FACADE                                 @@
*       @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
 */
    public static void testCustomerFacade() throws Exception {
        System.out.println("  START    testCompanyFacade();");
        String password = "1234";
        String email = "artur@gmail.com";
        LoginManager loginManager = LoginManager.getInstance();
        CustomerFacade customerFacade = (CustomerFacade) loginManager.login(email, password, ClientType.getClientTypeByIndex(3));
        //getCustomerDetails
        Customer customer = customerFacade.getCustomerDetails();
        System.out.println("=============================================================");
        System.out.println("    Hello autorized  customer  !" + customer.toString() + "\n" );

        System.out.println(" all coupons of CUSTOMER " + customer.getId() );
        TablePrinter.print(customerFacade.getCustomerCoupons());

        System.out.println(" all coupons of CUSTOMER " + customer.getId() + " under PRICE = 20" );
        TablePrinter.print(customerFacade.getCustomerCouponsUnderPrice(20.0));

        System.out.println(" all coupons of CUSTOMER " + customer.getId() + "by Category Vacatiov  "  );
        TablePrinter.print(customerFacade.getCustomerCouponsByCategory(Category.Vacation));

        System.out.println(" Pourshace coupon 7 by " + customer.getId() );
        Coupon coupon7 = new Coupon(7,5, Category.Vacation, "NIKE sales 13%", "sales 13%",
                Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf("2022-04-28"), 5, 999.99, "no Image ");
        customerFacade.purchaseCoupon(coupon7);
        TablePrinter.print(customerFacade.getCustomerCoupons());
        System.out.println(" WRONG pourshace coupon 7 by " + customer.getId() + "(already pourshaced)");
        customerFacade.purchaseCoupon(coupon7);

        TablePrinter.print(customerFacade.getCustomerCoupons());
//        ---------------------    amount = 0 ---------------------------
        System.out.println(" WRONG pourshace coupon 8 by " + customer.getId() + "(amount = 0)");
        Coupon coupon8 = new Coupon(8,5, Category.Vacation, "Puma sales 50%", "sales 50%",
                Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf("2022-04-28"), 0, 499.99, "no Image ");
        customerFacade.purchaseCoupon(coupon8);
        TablePrinter.print(customerFacade.getCustomerCoupons());
//   -------------------------------   date   expired---------------------
        System.out.println(" WRONG pourshace coupon 9 by " + customer.getId() + "(Date expired)");
        Coupon coupon9 = new Coupon(9,5, Category.Restaurant, "1+1 in Japanica", "1+1",
                Date.valueOf(LocalDate.now().minusWeeks(5)), Date.valueOf(LocalDate.now().minusWeeks(4)), 10, 499.99, "no Image ");
        customerFacade.purchaseCoupon(coupon8);
        TablePrinter.print(customerFacade.getCustomerCoupons());
    }
}


// System.out.println(Category.getCategoryByIndex(1));
//  IntStream.rangeClosed(1,Category.values().length - 1).mapToObj(ClientType::getClientTypeByIndex).forEach(System.out::print);