package beans;

public enum ClientType {
    Administrator,
    Company,
    Customer;

    public int getIdValue() {
        return this.ordinal() + 1;
    }

    public static ClientType getClientTypeByIndex(int index) {
        ClientType[] clientTypes = ClientType.values();
        return clientTypes[index - 1];
    }
}

