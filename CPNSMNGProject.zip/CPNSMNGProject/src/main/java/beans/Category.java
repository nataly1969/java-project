package beans;

public enum Category {
    Food,
    Electricity,
    Restaurant,
    Vacation;

    public int getIdValue() {
        return this.ordinal() + 1;
    }

    public static Category getCategoryByIndex(int index) {
        Category[] categories = Category.values();
        return categories[index - 1];
    }
}
