package beans;

public class CustomerVsCoupon {
    private int CustomerId;

    @Override
    public String toString() {
        return "CustomersVsCoupons{" +
                "CustomerId=" + CustomerId +
                ", CouponId=" + CouponId +
                '}';
    }

    public int getCustomerId() {
        return CustomerId;
    }

    public void setCustomerId(int customerId) {
        CustomerId = customerId;
    }

    public int getCouponId() {
        return CouponId;
    }

    public void setCouponId(int couponId) {
        CouponId = couponId;
    }

    public CustomerVsCoupon(int customerId, int couponId) {
        CustomerId = customerId;
        CouponId = couponId;
    }

    public CustomerVsCoupon() {
    }

    private int CouponId;

}
