package dao;
import beans.Company;
import java.sql.SQLException;
import java.util.List;

public interface CompaniesDAO {

    boolean isCompanyExistById(int Id) throws SQLException, InterruptedException;
    boolean isCompanyExist(String email, String password ) throws SQLException, InterruptedException;
    boolean isCompanyExistByEmail(String email ) throws SQLException, InterruptedException;
    boolean isCompanyExistByName(String name) throws SQLException, InterruptedException;
    void addCompany(Company company) throws SQLException, InterruptedException;
    void updateCompany(Company company) throws SQLException, InterruptedException;
    void deleteCompany(int ID) throws SQLException, InterruptedException;

    List<Company> getAllCompanies() throws SQLException, InterruptedException;
    Company getOneCompany(int Id) throws SQLException, InterruptedException;
    Company getCompanyByEmailPassword(String email , String password) throws SQLException, InterruptedException;

}
