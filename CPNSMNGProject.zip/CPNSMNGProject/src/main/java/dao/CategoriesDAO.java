package dao;

import beans.Category;

import java.sql.SQLException;
import java.util.List;

public interface CategoriesDAO {
    void addCategory(Category category) throws SQLException;
    void deleteAllCategories() throws SQLException;
    List<Category> getAllCategories() throws SQLException;
    boolean isCategoryExistByIndex(Category category) throws SQLException, InterruptedException;



}
