package dao;

import beans.Customer;

import java.sql.SQLException;
import java.util.List;

public interface CustomersDAO {
    boolean isCustomerExistById(int Id) throws SQLException, InterruptedException;
    boolean isCustomerExistByEmail(String email) throws SQLException, InterruptedException;
    boolean isCustomerExist(String email, String password ) throws SQLException, InterruptedException;
    void addCustomer(Customer customer) throws SQLException, InterruptedException;
    void updateCustomer(Customer customer) throws SQLException, InterruptedException;
    void deleteCustomer(int ID) throws SQLException, InterruptedException;
    List<Customer> getAllCustomers() throws SQLException, InterruptedException;
    Customer getOneCustomer(int Id) throws SQLException, InterruptedException;
    Customer getCustomerByEmail(String email) throws SQLException, InterruptedException;
    Customer getCustomerByEmailPass(String email,String password) throws SQLException, InterruptedException;
}
