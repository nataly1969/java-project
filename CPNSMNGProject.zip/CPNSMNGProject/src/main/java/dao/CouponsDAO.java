package dao;

import beans.Category;
import beans.Coupon;

import java.sql.SQLException;
import java.util.List;

public interface CouponsDAO {
   /* boolean isCouponExist(Coupon coupon) throws SQLException;*/

//    void updateCoupon(Coupon coupon) throws SQLException;
//    void deleteCoupon(int couponId) throws SQLException;
//
//    List<Coupon> getAllCoupons() throws SQLException;
//    Coupon getOneCoupon(int couponId) throws SQLException;
//    void addCouponPurchase(int customer_Id, int couponId) throws SQLException;
//    void deleteCouponPurchase(int customer_Id, int couponId) throws SQLException;

 void addCoupon(Coupon coupon) throws SQLException, InterruptedException;

 void updateCoupon(Coupon coupon) throws SQLException, InterruptedException;

 void deleteCoupon(int couponId) throws SQLException, InterruptedException;

 List<Coupon> getAllCoupons() throws SQLException, InterruptedException;
 List<Coupon> getAllCouponsExpiredDate() throws SQLException, InterruptedException;

 List<Coupon> getAllCustomerCoupons(int customerId) throws SQLException;
 List<Coupon> getAllCompanyCoupons(int companyId) throws SQLException;

 List<Coupon> getAllCompanyCouponsByCategory(int companyId, Category category) throws SQLException;
 List<Coupon> getAllCustomerCouponsByCategory(int customerId, Category category) throws SQLException;

 List<Coupon> getAllCompanyCouponsByUnderPrice(int companyId, double price) throws SQLException;
 List<Coupon> getAllCustomerCouponsUnderPrice(int customerId, double price) throws SQLException;

 //   -------------------get  ONE   ----------------------------
 Coupon getOneCouponById(int couponId) throws SQLException, InterruptedException;
 Coupon getOneCouponOfCompanyCategory(int couponId,int companyId,Category category) throws SQLException, InterruptedException;
 Coupon getOneCouponOfCompanyByTitle(int companyId,String title) throws SQLException, InterruptedException;
//   -------------------  is Exists  ------------------------
 boolean isCouponExist(int couponId) throws SQLException, InterruptedException;
 boolean isExistCouponInStock(int couponId) throws SQLException, InterruptedException;
 boolean isExistsCompanyCouponByTitle(int couponId,String title) throws SQLException, InterruptedException;
 boolean isExistCouponOfCompanyCategory(int couponId,int companyId,Category category) throws SQLException, InterruptedException;
//    ---------------------   other ---------------------------
 void deleteCompanyCoupons(int companyId) throws SQLException, InterruptedException;
 void reduceAmountOfOnePurchasedCoupon(int couponId) throws SQLException, InterruptedException;

}
