package dao;

import beans.CustomerVsCoupon;

import java.sql.SQLException;
import java.util.List;

public interface CustomersVsCouponsDAO {
        List<CustomerVsCoupon> getAllCustomersVsCoupons() throws SQLException, InterruptedException;
        void addCouponPurchase(int customerId, int couponId) throws SQLException, InterruptedException;
        void deleteCouponPurchase(int customerId, int couponId) throws SQLException, InterruptedException;
        void deleteCouponPurchaseById(int couponId) throws SQLException, InterruptedException;
        void deleteCompanyCouponPurchase(int companyId) throws SQLException, InterruptedException;
        void deleteAllCustomerCouponsPurshase(int customerId) throws SQLException, InterruptedException;
        boolean isExistCouponPurchasedByCustomer(int customerId,int couponId) throws SQLException, InterruptedException;
        //---------------not need here ---------------------
        //      // void addCustomersVsCoupons(Category category) throws SQLException;
        // // void deleteAllCategories() throws SQLException;
        // // void deleteOneCustomersVsCoupons(Category category) throws SQLException;
        // // void deleteAllOneCustomersVsCoupons(Category category) throws SQLException;
}
