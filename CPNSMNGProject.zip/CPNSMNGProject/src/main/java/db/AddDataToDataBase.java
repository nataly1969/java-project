package db;

import beans.Category;
import beans.Company;
import beans.Coupon;
import beans.Customer;
import dao.*;
import daoImpl.*;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;

public class AddDataToDataBase {
    public static void FillCompaniesTable() throws SQLException, InterruptedException {
       //        System.out.println("\n" + "--------------------Fill Companies Table in DB2 --------------------------");
        CompaniesDAO companiesDAO = new CompaniesDAOImpl();

        Company company1 = new Company("Max Brenner", "MaxBrenner@gmail.com", "1234");
        Company company2 = new Company("Rukkola", "Rukkola@gmail.com", "1234");
        Company company3 = new Company("MegaSport", "MegaSport@gmail.com", "1234");
        Company company4 = new Company("FootLocker", "FootLocker@gmail.com", "1234");
        Company company5 = new Company("Nike", "nike@gmail.com", "1234");
        Company company6 = new Company("ISROTEL", "isrotel@gmail.com", "1234");
        //System.out.println(company3);
        for (Company company : Arrays.asList(company1, company2, company3, company4, company5,company6)) {
            companiesDAO.addCompany(company);
//        }TablePrinter.print(companiesDAO.getAllCompanies());
            //================  END  Fill Companies ==========================
        }
    }
//===============================================================================================//
        public static void FillCustomersTable () throws SQLException, InterruptedException {
            // System.out.println(Art.DAO_CUSTOMER);
//            System.out.println("--------------------Fill Customers Table in DB2 --------------------------");
            CustomersDAO customersDAO = new CustomersDAOImpl();

            Customer customer1 = new Customer("Max", "Chokolatier", "choklatier@mail.ru", "1234");
            Customer customer2 = new Customer("Rollo", "Dinnerov", "dinnerov@mail.ru", "1234");
            Customer customer3 = new Customer("Eli", "Sportsmen", "eli@gmail.com", "1234");
            Customer customer4 = new Customer("Geula", "Sportsmen", "geula@gmail.com", "1234");
            Customer customer5 = new Customer("Artur", "Sportsmen", "artur@gmail.com", "1234");
            for (Customer customer : Arrays.asList(customer1, customer2, customer3, customer4, customer5)) {
                customersDAO.addCustomer(customer);
            }
            //  TablePrinter.print(customersDAO.getAllCustomers());
            //          ================  END Fill Customers==========================
        }
//===============================================================================================//
        public static void FillCategoriesTable () throws SQLException, InterruptedException {
            //System.out.println(Art.DAO_CATEGORY);
            //System.out.println("\n" + "--------------------Fill Categories Table in DB2 --------------------------");
            //          ================  END Fill Categories==========================
            CategoriesDAO categoriesDAO = new CategoriesDAOImpl();
            Category category1 = Category.Food;
            Category category2 = Category.Electricity;
            Category category3 = Category.Restaurant;
            Category category4 = Category.Vacation;

            for (Category category : Arrays.asList(category1, category2, category3, category4)) {
                categoriesDAO.addCategory(category);
            }
            //??? TablePrinter.print(categoriesDAO.getAllCategories());
            //???  System.out.println(categoriesDAO.getAllCategories());
            //???  categoriesDAO.getAllCategories().forEach(System.out::println );
            //          ================  END Fill Categories   ==========================

        }
//===============================================================================================//
        public static void FillCouponsTable () throws SQLException, InterruptedException {
            //System.out.println(Art.DAO_COUPON);
//            System.out.println("--------------------Fill Coupons Table in DB2 --------------------------");
            CouponsDAO couponsDAO = new CouponsDAOImpl();
            Coupon coupon1 = new Coupon(1, Category.Food, "Youchananov sale 30%", "Sales in Beef ",
                    Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf(LocalDate.now().plusWeeks(1)), 5, 1.2, "no Image ");
            Coupon coupon2 = new Coupon(1, Category.Restaurant, "1+1 in Japanica", "1+1",
                    Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf(LocalDate.now().plusWeeks(2)), 5, 1, "no Image ");
            Coupon coupon3 = new Coupon(3, Category.Restaurant, "Megasport bycikles sales 30%", "sales 30%",
                    Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf(LocalDate.now().plusWeeks(3)), 5, 3, "no Image ");
            Coupon coupon4 = new Coupon(3, Category.Vacation, "MegaSport Rollers sales 50%", "sales 50%",
                    Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf(LocalDate.now().plusWeeks(4)), 5, 3, "no Image ");
            Coupon coupon5 = new Coupon(4, Category.Vacation, "FootLocker sales 30%", "sales 30%",
                    Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf(LocalDate.now().plusWeeks(5)), 5, 4, "no Image ");
            Coupon coupon6 = new Coupon(5, Category.Vacation, "Vacations in Berlin sales 3%", "Passover vacations",
                    Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf("2022-04-28"), 5, 50, "no Image ");
            Coupon coupon7 = new Coupon(5, Category.Vacation, "NIKE sales 13%", "sales 13%",
                    Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf("2022-04-28"), 5, 999.99, "no Image ");
            Coupon coupon8 = new Coupon(5, Category.Vacation, "Puma sales 50%", "sales 50%",
                    Date.valueOf(LocalDate.now().minusWeeks(1)), Date.valueOf("2022-04-28"), 0, 499.99, "no Image ");
            Coupon coupon9 = new Coupon(5, Category.Restaurant, "1+1 in Japanica", "1+1",
                    Date.valueOf(LocalDate.now().minusWeeks(5)), Date.valueOf(LocalDate.now().minusWeeks(4)), 10, 499.99, "no Image ");
            Coupon coupon10 = new Coupon(6, Category.Vacation, "1+1 in ISROTEL Eilat", "1+1",
                    Date.valueOf(LocalDate.now().minusWeeks(5)), Date.valueOf(LocalDate.now()), 5, 499.99, "no Image ");
            Coupon coupon11 = new Coupon(6, Category.Vacation, "1+1 in Tel-Aviv", "1+1",
                    Date.valueOf(LocalDate.now().minusWeeks(5)), Date.valueOf(LocalDate.now().minusWeeks(3)), 5, 499.99, "no Image ");
            Coupon coupon12 = new Coupon(6, Category.Vacation, "1+1 in Tveria", "1+1",
                    Date.valueOf(LocalDate.now().minusWeeks(5)), Date.valueOf(LocalDate.now().minusWeeks(2)), 5, 499.99, "no Image ");
            Coupon coupon13 = new Coupon(6, Category.Vacation, "1+1 in Jerusalem", "1+1",
                    Date.valueOf(LocalDate.now().minusWeeks(5)), Date.valueOf(LocalDate.now().minusWeeks(1)), 5, 499.99, "no Image ");
            Coupon coupon14 = new Coupon(6, Category.Vacation, "1+1 in Beer-Sheva", "1+1",
                    Date.valueOf(LocalDate.now().minusWeeks(5)), Date.valueOf(LocalDate.now().minusDays(1)), 1, 499.99, "no Image ");


            for (Coupon coupon : Arrays.asList(coupon1, coupon2, coupon3, coupon4, coupon5, coupon6, coupon7, coupon8,coupon9,coupon10,coupon11,coupon12,coupon13,coupon14)) {
                couponsDAO.addCoupon(coupon);
            }
//        TablePrinter.print(couponsDAO.getAllCoupons());
//     -========================  END Fill Coupons==========================

        }
//===============================================================================================//
        public static void FillCustomersVsCouponsTable () throws SQLException, InterruptedException {
            // System.out.println(Art.DAO_CUSTOMER_VS_COPMPANY);
//            System.out.println("--------------------Fill CustomersVsCoupons Table in DB2 --------------------------");
            CustomersVsCouponsDAO customersVsCouponsDAO = new CustomersVsCouponsDAOImpl();

            customersVsCouponsDAO.addCouponPurchase(1, 5);
            customersVsCouponsDAO.addCouponPurchase(1, 6);
            customersVsCouponsDAO.addCouponPurchase(2, 1);
            customersVsCouponsDAO.addCouponPurchase(2, 5);
            customersVsCouponsDAO.addCouponPurchase(2, 4);
            customersVsCouponsDAO.addCouponPurchase(1, 1);
            customersVsCouponsDAO.addCouponPurchase(5, 1);
            customersVsCouponsDAO.addCouponPurchase(5, 5);
            customersVsCouponsDAO.addCouponPurchase(5, 4);
            customersVsCouponsDAO.addCouponPurchase(5, 6);

            //       TablePrinter.print(customersVsCouponsDAO.getAllCustomersVsCoupons());

//        customersVsCouponsDAO.deleteCompanyCouponPurchase(4);
//        couponsDAO.deleteCompanyCoupons(4);
//        TablePrinter.print(customersVsCouponsDAO.getAllCustomersVsCoupons());
//        customersVsCouponsDAO.deleteCustomersCoupons(1);
//        TablePrinter.print(customersVsCouponsDAO.getAllCustomersVsCoupons());
//        if (couponsDAO.isCompanyCouponExistByTitle(coupon1)) {
//                System.out.println(" Finded coupon 1 by name  = "   );
//         } else {
//            System.out.println("my coupon1 not finded by name ");
//        }
            //&&&&&&&&&&&&&&&&
//        try {
//            DatabaseManager.databaseStrategy();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
            //          ================  END Fill Customers_Vs_Coupons==========================
        }

    }
