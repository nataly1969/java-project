package db;

import beans.*;

import java.sql.Date;
import java.util.HashMap;

public class ResultUtils {
    public static Company fromHashMapToCompany(HashMap<Integer, Object> row) {
        int id = (int) row.get("id");
        String name = (String) row.get("name");
        String email = (String) row.get("email");
        String password = (String) row.get("password");
        Company company = new Company(id, name, email, password);
        return company;
    };
    public static Customer fromHashMapToCustomer(HashMap<Integer, Object> row) {
        int id = (int) row.get("id");
        String firstName = (String) row.get("first_name");
        String lastName = (String) row.get("last_name");
        String email = (String) row.get("email");
        String password = (String) row.get("password");
        Customer customer = new Customer(id, firstName,lastName,email, password);
        return customer;
    }; public static CustomerVsCoupon fromHashMapToCustVsCoupon(HashMap<Integer, Object> row) {
        int customerId = (int) row.get("customer_id");
        int couponId = (int) row.get("coupon_id");
        CustomerVsCoupon customerVsCoupon = new CustomerVsCoupon(customerId,couponId);
        return customerVsCoupon;
    };
  
    public static Coupon fromHashMapToCoupon(HashMap<Integer, Object> row) {
        int id = (int) row.get("id");
        int companyId = (int) row.get("company_id");
        int categoryId = (int) row.get("category_id");
        Category.getCategoryByIndex(categoryId);
        String title = (String) row.get("title");
        String description = (String) row.get("description");
        Date startDate = (java.sql.Date) row.get("start_date");
        Date endDate    = (java.sql.Date) row.get("end_date");
        int amount =(int) row.get("amount");
        double price =(double) row.get("price");
        String image = (String) row.get("image");
        Coupon coupon = new Coupon(id,companyId,Category.getCategoryByIndex(categoryId),title,description,startDate,endDate,amount,price,image);

        return coupon;
    };
    public static Category fromHashMapToCategory(HashMap<Integer, Object> row) {
        int id = (int) row.get("id");
        String name = (String) row.get("name");
        Category category = null;
        //category = new Category();
        return category.getDeclaringClass().cast(category);
    };
    /* ---------------------HASH to TYPES -------------------- */
    public static boolean fromHashMapToBoolean(HashMap<Integer, Object> row) {
        long res = (long) row.get("res");
        return (res == 1);
    };
    public static double fromHashMapToDouble(HashMap<Integer, Object> row) {
        double res = (double) row.get("res");
        return  res;
    };
    public static double fromHashMapToInt(HashMap<Integer, Object> row) {
        long res =(long) row.get("res");
        return  res;
    }
    public static Date fromHashMapToDate(HashMap<Integer, Object> row) {
        Date res =(Date) row.get("res");
        return  res;
    }
}

