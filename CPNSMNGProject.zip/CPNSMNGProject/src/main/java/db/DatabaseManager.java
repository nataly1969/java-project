package db;

import java.sql.SQLException;

/**
 * Created by Nataly 03 Apr, 2022
 */
public class DatabaseManager {


    private static final String CREATE_SCHEMA = "create schema cpnsmng";
    private static final String DROP_SCHEMA = "drop schema cpnsmng";
    private static final String CREATE_TABLE_COMPANIES = "CREATE TABLE `cpnsmng`.`companies` (\n" +
            " `id` INT NOT NULL AUTO_INCREMENT,\n" +
            "`name` VARCHAR(45) NOT NULL,\n" +
            "`email` VARCHAR(45) NOT NULL,\n" +
            "`password` VARCHAR(45) NOT NULL,\n" +
            " PRIMARY KEY (`id`));";
    private static final String CREATE_TABLE_CUSTOMERS = "CREATE TABLE `cpnsmng`.`customers` (\n" +
            "  `id` INT NOT NULL AUTO_INCREMENT,\n" +
            " `first_name` VARCHAR(45) NOT NULL,\n" +
            " `last_name` VARCHAR(45) NOT NULL,\n" +
            "  `email` VARCHAR(45) NOT NULL,\n" +
            "  `password` VARCHAR(45) NULL,\n" +
            "   PRIMARY KEY (`id`));";

    private static final String CREATE_TABLE_CATEGORIES = "CREATE TABLE `cpnsmng`.`categories` (\n" +
            // "  `id` INT NOT NULL AUTO_INCREMENT,\n" +
            "  `id` INT NOT NULL ,\n" +
            " `name` VARCHAR(45) NOT NULL,\n" +
            "   PRIMARY KEY (`id`));";

    private static final String CREATE_TABLE_COUPONS = "CREATE TABLE `cpnsmng`.`coupons` (\n" +
            "   `id` INT NOT NULL AUTO_INCREMENT,\n" +
            "`company_id` INT NULL,\n" +
            "`category_id` INT NULL,\n" +
            " `title` varchar(45) NOT NULL,\n" +
            "  `description` varchar(45) NOT NULL,\n" +
            "  `start_date` date NOT NULL,\n" +
            "   `end_date` date NOT NULL,\n" +
            "   `amount` int  NOT NULL,\n" +
            "  `price` double  NOT NULL,\n" +
            "  `image` varchar(45) NOT NULL,\n" +
            " PRIMARY KEY (`id`),\n" +
            " INDEX `company_id_idx` (`company_id` ASC) VISIBLE,\n" +
            " INDEX `category_id_idx` (`category_id` ASC) VISIBLE,\n" +
            " CONSTRAINT `company_id`\n" +
            " FOREIGN KEY (`company_id`)\n" +
            " REFERENCES `cpnsmng`.`companies` (`id`)\n" +
            " ON DELETE NO ACTION\n" +
            " ON UPDATE NO ACTION,\n" +
            " CONSTRAINT `category_id`\n" +
            " FOREIGN KEY (`category_id`)\n" +
            " REFERENCES `cpnsmng`.`categories` (`id`)\n" +
            " ON DELETE NO ACTION\n" +
            " ON UPDATE NO ACTION);";
    private static final String CREATE_TABLE_CUST_VS_CPN = "CREATE TABLE `cpnsmng`.`customer_vs_coupons` (\n" +

            "  `customer_id` INT NOT NULL,\n" +
            "  `coupon_id` INT NOT NULL,\n" +
            "  PRIMARY KEY (`customer_id`, `coupon_id`),\n" +
            "  INDEX `coupon_id_idx` (`coupon_id` ASC) VISIBLE,\n" +
            "  CONSTRAINT `customer_id`\n" +
            "    FOREIGN KEY (`customer_id`)\n" +
            "    REFERENCES `cpnsmng`.`customers` (`id`)\n" +
            "    ON DELETE NO ACTION\n" +
            "    ON UPDATE NO ACTION,\n" +
            "    CONSTRAINT `coupon_id`\n" +
            "    FOREIGN KEY (`coupon_id`)\n" +
            "    REFERENCES `cpnsmng`.`coupons` (`id`)\n" +
            "    ON DELETE NO ACTION\n" +
            "    ON UPDATE NO ACTION);";
    /**
     * --------------------------companies  queries --------------//
     */
    public static final String QUERY_INSERT_CMP = "INSERT INTO `cpnsmng`.`companies` (`name`,`email`,`password`)\n" +
                                                  " VALUES (trim(?),trim(?),trim(?))";
    public static final String QUERY_DELETE_CMP = "DELETE FROM cpnsmng.companies WHERE ID = ?;";
    public static final String QUERY_UPDATE_CMP = "UPDATE cpnsmng.companies set email = trim(?) , password = trim(?)\n" +
                                                 " where id = ?;";
    public static final String Q_SELECT_BY_ID_CMP = "SELECT * from  cpnsmng.companies where id = ?;";
    public static final String Q_SELECT_CMP_BY_EMAIL_PASSWORD = "SELECT * from  cpnsmng.companies where email = ? and password = ?;";
    public static final String Q_ALL_Companies = "SELECT * from  cpnsmng.companies;";

    public static final String Q_IS_EXIST_COMPANY_BY_ID = "select exists (SELECT * from  cpnsmng.companies where id = ?) as res";
    public static final String Q_IS_EXIST_COMPANY = "select exists (SELECT * from  cpnsmng.companies where email = ? and password = ?) as res";
    public static final String Q_IS_EXIST_COMPANY_BY_NAME = "select exists (SELECT * from  cpnsmng.companies \n"
            + "where name = trim(?)) as res";
    public static final String Q_IS_EXIST_COMPANY_BY_MAIL = "select exists (SELECT * from  cpnsmng.companies \n"
            + "where email = trim(?)) as res";
    /**
     * --------------------------customers  queries --------------//
     */
    public static final String QUERY_INSERT_CUST = "INSERT INTO `cpnsmng`.`customers` (`first_name`,\n" +
            " `last_name`, `email`, `password`) VALUES ( trim(?), trim(?), trim(?), trim(?));";
    public static final String QUERY_DELETE_CUST = "DELETE FROM cpnsmng.customers WHERE ID = ?;";
    public static final String QUERY_UPDATE_CUST = "UPDATE cpnsmng.customers \n" +
            "set first_name = trim(?) , last_name = trim(?) ,\n" +
            "email = trim(?) , password = trim(?) where id = ?;";
    public static final String Q_SELECT_BY_ID_CUST = "SELECT * from  cpnsmng.customers where id = ?;";

    public static final String Q_ALL_Customers = "SELECT * from  cpnsmng.customers;";
    public static final String Q_IS_EXIST_CUSTOMER_BY_ID = "select exists (SELECT * from  cpnsmng.customers where id = ?) as res";
    //public static final String SELECT_FROM_CPNSMNG_CUSTOMERS_WHERE_EMAIL_TRIM = "SELECT * FROM cpnsmng.customers where email = ?;";
    public static final String Q_IS_EXIST_CUSTOMER_BY_EMAIL = "select exists (SELECT * from cpnsmng.customers where email = trim(?)) as res";
    public static final String Q_SELECT_CUSTOMER_BY_EMAIL = "SELECT *  from cpnsmng.customers where email = trim(?);";
    public static final String Q_SELECT_CUSTOMER_BY_EMAIL_PASS = "SELECT *  from cpnsmng.customers where email = ? and password = ?;";
    public static final String Q_IS_EXIST_CUSTOMER = "select exists (SELECT * from  cpnsmng.customers where email = trim(?) and password = trim(?)) as res";
    /* --------------------------category  queries -----------------------------------*/
    public static final String QUERY_INSERT_CATEGORY = "INSERT INTO `cpnsmng`.`categories` (`id`, `name`) VALUES ( ?, trim(?));";
    //public static final String QUERY_INSERT_CATEGORY ="INSERT INTO `cpnsmng`.`categories` (`name`) VALUES (?);";
    public static final String QUERY_DELETE_CATEGORY = "DELETE FROM cpnsmng.categories WHERE ID = ?;";
    public static final String Q_ALL_Categories = "SELECT * from  cpnsmng.categories;";
    public static final String Q_DELETE_ALL_CATEGORIES = "DELETE FROM cpnsmng.categories WHERE ID <> ?;";
    public static final String IS_CATEGORY_EXISTS_BY_ID = "select exists (SELECT * FROM cpnsmng.categories WHERE ID <> ?) as res";

    /*   ---------------------------  coupon queries -----------------------------------*/
    public static final String QUERY_INSERT_COUPON = "INSERT INTO `cpnsmng`.`coupons` (`company_id`, `category_id`, `title`,\n" +
            "`description`, `start_date`, `end_date`, `amount`, `price`, `image`) \n" +
            " VALUES (?, ?, trim(?), trim(?), ?, ?, ?, ?, trim(?));";
    public static final String Q_ALL_COUPONS = "SELECT * from  cpnsmng.coupons;";
    public static final String Q_ALL_COUPONS_EXPIRED_DATE = "SELECT * from  cpnsmng.coupons WHERE  end_date <= current_date()";
   // public static final String Q_ALL_COUPONS_EXPIRED_DATE = "SELECT * from  cpnsmng.coupons where end_date > ? ";
   // public static final String Q_ALL_COUPONS_EXPIRED_DATE = "SELECT * from  cpnsmng.coupons;";
    public static final String Q_SELECT_COUPON_BY_ID = "SELECT * from  cpnsmng.coupons where id = ?;";
    public static final String Q_SELECT_ALL_COMPANY_COUPONS = "SELECT * from  cpnsmng.coupons where company_id = ?;";
    public static final String Q_ALL_COMPANY_COUPONS_UNDER_PRICE = "SELECT * from  cpnsmng.coupons \n" +
            " where company_id = ? and price <= ?;";
    public static final String Q_SELECT_ALL_COMPANY_COUPONS_CATEG = "SELECT * from  cpnsmng.coupons \n" +
            "where company_id = ? and category_id = ?;";
    public static final String Q_CPN_BY_ID_COMPANY_CATEGORY = "SELECT * from  cpnsmng.coupons \n" +
        "where id = ? and company_id = ? and category_id = ?;";
    public static final String Q_ONE_COMPANY_COUPON_BY_TITLE = "SELECT * from  cpnsmng.coupons \n" +
            "where company_id = ? and title = trim(?);";
    public static final String Q_IS_EXIST_CPN_BY_FULL_KEY = "select exists (SELECT * from  cpnsmng.coupons \n" +
            "where id = ? and company_id = ? and category_id = ?) as res";
    public static final String Q_IS_EXIST_COUPON_IN_STOCK = "select exists (SELECT * FROM cpnsmng.coupons where id = ?\n" +
         "and amount > 0 and end_date > current_date()) as res";
    public static final String Q_All_Customer_Coupons = "SELECT * FROM cpnsmng.coupons where id \n" +
            "in (select coupon_Id from cpnsmng.customer_vs_coupons\n" +
            "WHERE customer_id = ?);";
    public static final String Q_ALL_CUSTOMER_COUPONS_UNDER_PRICE = "SELECT * FROM cpnsmng.coupons where price <= ? and id in \n" +
            "  (select coupon_Id from cpnsmng.customer_vs_coupons  WHERE customer_id = ?);" ;
    //todo
    public static final String Q_SELECT_ALL_CUSTOMER_COUPONS_CATEG = "SELECT * FROM cpnsmng.coupons where category_id = ? and id in \n" +
            "(select coupon_Id from cpnsmng.customer_vs_coupons  WHERE customer_id = ?);" ;
    public static final String Q_DELETE_COUPON_PURCHASE = "delete  from cpnsmng.coupons where company_id = ? and category_id = ?;";
    public static final String Q_DELETE_COUPON_BY_ID = "delete  from cpnsmng.coupons where id = ?;";
    public static final String Q_DELETE_COMPANY_COUPONS = "delete from cpnsmng.coupons where company_id = ?;";
    public static final String Q_UPDATE_COUPON = "update cpnsmng.coupons\n" +
            "set category_id = ? , title = trim(?) , description = trim(?) , start_date = ? , end_date = ? ,\n" +
            "amount = ? , price = ? , image = trim(?) WHERE id = ?;";
    public static final String Q_IS_EXIST_COUPON =
            "select exists(SELECT * FROM cpnsmng.coupons WHERE Id = ?) as res";

    public static final String Q_IS_Exist_Coupon_Purchased_By_CUSTOMER = "select exists(SELECT * FROM cpnsmng.coupons a where a.Id = ? and exists (\n" +
        "        select * from cpnsmng.customer_vs_coupons b where b.coupon_id = a.id  \n" +
        "        and b.customer_id  = ?) ) as res";
    public static final String Q_IS_EXIST_COMPANY_COUPON_BY_TITLE = "select exists (SELECT * FROM cpnsmng.coupons \n" +
            " WHERE company_id = ? and title = ?) as res";

    public static final String Q_UPDATE_AMOUNT_PURSHACED_CUSTOMER_COUPONS ="UPDATE cpnsmng.coupons SET amount = amount - 1 WHERE id = ?;";

    /* ------------------------------customer_vs_coupons ------------------------------- */
    public static final String Q_ALL_CustomersVsCoupons = "SELECT * from cpnsmng.customer_vs_coupons;";
  //    public static final String Q_IS_EXIST_COUPON =
//            "select exists(SELECT * FROM cpnsmng.coupons WHERE Id = ?) as res";
    public static final String Q_INSERT_COUPON_PURCHASE = "INSERT INTO cpnsmng.customer_vs_coupons \n" +
            "(customer_id,coupon_id) VALUES (?, ?);";
    public static final String Q_DELETE_COUPON_PURCHASED_BY_COUPON_ID = "delete  FROM cpnsmng.customer_vs_coupons \n" +
            " where coupon_id = ? ;";
    public static final String Q_DELETE_COUPON_PURCHASE_BY_CUSTOMER = "delete  FROM cpnsmng.customer_vs_coupons \n" +
            " where customer_id = ? and coupon_id = ? ;";
    public static final String Q_DELETE_COMPANY_COUPON_PURCHASE = "DELETE FROM cpnsmng.customer_vs_coupons\n" +
            "where Coupon_Id in (SELECT Id  FROM cpnsmng.coupons\n" +
            "                   WHERE company_Id = 1 );";
    public static final String Q_DELETE_CUSTOMER_COUPONS = "DELETE FROM cpnsmng.customer_vs_coupons where customer_Id = ?";

    /**
     * -----------------------------  db strategy ---------------------------------------//
     */

    public static void databaseStrategy() throws SQLException {
        try {
            JDBCUtils.execute(DROP_SCHEMA);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        JDBCUtils.execute(CREATE_SCHEMA);
        JDBCUtils.execute(CREATE_TABLE_COMPANIES);
        JDBCUtils.execute(CREATE_TABLE_CUSTOMERS);
        JDBCUtils.execute(CREATE_TABLE_CATEGORIES);
        JDBCUtils.execute(CREATE_TABLE_COUPONS);
        JDBCUtils.execute(CREATE_TABLE_CUST_VS_CPN);
    }


}