package daoImpl;

import beans.Customer;
import dao.CustomersDAO;
import db.DatabaseManager;
import db.JDBCUtils;
import db.ResultUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CustomersDAOImpl implements CustomersDAO {
    @Override
    public boolean isCustomerExist(String email, String password ) throws SQLException {
        boolean isExist = false;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, email);
        map.put(2,password);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_IS_EXIST_CUSTOMER, map);
        for (Object row : res) {
            isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;  }
        return isExist;
    };
    @Override
    public boolean isCustomerExistById(int Id) throws SQLException {
        boolean isExist = false;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, Id);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_IS_EXIST_CUSTOMER_BY_ID, map);
        for (Object row : res) {
            isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;  }
        return isExist;
    }
    @Override
    public boolean isCustomerExistByEmail(String email) throws SQLException {
        boolean isExist = false;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, email);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_IS_EXIST_CUSTOMER_BY_EMAIL, map);
        for (Object row : res) {
            isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;  }
        return isExist;
    }
    @Override
    public void addCustomer(Customer customer) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customer.getFirstName());
        map.put(2, customer.getLastName());
        map.put(3, customer.getEmail());
        map.put(4, customer.getPassword());
        JDBCUtils.execute(DatabaseManager.QUERY_INSERT_CUST, map);
    }

    @Override
    public void updateCustomer(Customer customer) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customer.getFirstName());
        map.put(2, customer.getLastName());
        map.put(3, customer.getEmail());
        map.put(4, customer.getPassword());
        map.put(5, customer.getId());
        JDBCUtils.execute(DatabaseManager.QUERY_UPDATE_CUST, map);
    }

    @Override
    public void deleteCustomer(int Id) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1,Id);
        JDBCUtils.execute(DatabaseManager.QUERY_DELETE_CUST, map);
    }
    @Override
    public List<Customer> getAllCustomers() throws SQLException {
        List<Customer> customers = new ArrayList<>();
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_ALL_Customers);
        for (Object row : res) {
            customers.add( ResultUtils.fromHashMapToCustomer((HashMap<Integer, Object>) row));
        }
        return customers;
    };

    @Override
    public Customer getCustomerByEmail(String email) throws SQLException, InterruptedException {
        Customer customer = new Customer();
        Map<Integer, Object> map = new HashMap<>();
        map.put(1,email);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_SELECT_CUSTOMER_BY_EMAIL,map);
        for (Object row : res) {
            customer = (ResultUtils.fromHashMapToCustomer((HashMap<Integer, Object>) row));
            break;}
        return customer;
    }

    @Override
    public Customer getOneCustomer(int Id) throws SQLException {
        Customer customer = null;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1,Id);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_SELECT_BY_ID_CUST,map);
        for (Object row : res) {
            customer = (ResultUtils.fromHashMapToCustomer((HashMap<Integer, Object>) row));
            break;}
        return customer;
    }

    @Override
    public Customer getCustomerByEmailPass(String email, String password) throws SQLException, InterruptedException {
        Customer customer = null;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1,email);
        map.put(2,password);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_SELECT_CUSTOMER_BY_EMAIL_PASS,map);
        for (Object row : res) {
            customer = (ResultUtils.fromHashMapToCustomer((HashMap<Integer, Object>) row));
            break;}
        return customer;
    }
}
