package daoImpl;

import beans.Category;
import dao.CategoriesDAO;
import db.DatabaseManager;
import db.JDBCUtils;
import db.ResultUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CategoriesDAOImpl implements CategoriesDAO {
    @Override
    public void addCategory(Category category) throws SQLException    {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, category.getIdValue());
        map.put(2, category.name());
       // map.put(1, category.name());
        JDBCUtils.execute(DatabaseManager.QUERY_INSERT_CATEGORY, map);
    }
    @Override
    public List<Category> getAllCategories() throws SQLException {
        List<Category> categories = new ArrayList<>();
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_ALL_Categories);
        for (Object row : res) {
       categories.add( ResultUtils.fromHashMapToCategory((HashMap<Integer, Object>) row));
        }
        return categories;}

     @Override
    public boolean isCategoryExistByIndex(Category category) throws SQLException, InterruptedException {
         boolean isExist = false;
         Map<Integer, Object> map = new HashMap<>();
         map.put(1, category.getIdValue());
         List<?> res = JDBCUtils.executeResults(DatabaseManager.IS_CATEGORY_EXISTS_BY_ID, map);
         for (Object row : res) {
             isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
             break;  }
         return isExist;

    }

    //-------------------------delete category -----------------------
 @Override
 public void deleteAllCategories() throws SQLException {
     Map<Integer, Object> map = new HashMap<>();
     map.put(1, 0);
     JDBCUtils.execute(DatabaseManager.Q_DELETE_ALL_CATEGORIES, map);
 }
     //   @Override
 //   public void deleteCategory(int Id) throws SQLException {
//QUERY_DELETE_CATEGORY
  }
