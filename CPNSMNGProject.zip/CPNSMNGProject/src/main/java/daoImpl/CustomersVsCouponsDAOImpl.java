package daoImpl;

import beans.CustomerVsCoupon;
import dao.CustomersVsCouponsDAO;
import db.DatabaseManager;
import db.JDBCUtils;
import db.ResultUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CustomersVsCouponsDAOImpl implements CustomersVsCouponsDAO {
    @Override
    public List<CustomerVsCoupon> getAllCustomersVsCoupons() throws SQLException {
        List<CustomerVsCoupon> customerVsCoupons = new ArrayList<>();
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_ALL_CustomersVsCoupons);
        for (Object row : res) {
            customerVsCoupons.add(ResultUtils.fromHashMapToCustVsCoupon((HashMap<Integer, Object>) row));
        }
        return customerVsCoupons;
    }
    @Override
    public void addCouponPurchase(int customerId, int couponId) throws SQLException, InterruptedException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerId);
        map.put(2, couponId);
        JDBCUtils.execute(DatabaseManager.Q_INSERT_COUPON_PURCHASE, map);
    }
    @Override
    public void deleteCouponPurchase(int customerId, int couponId) throws SQLException, InterruptedException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerId);
        map.put(2, couponId);
        JDBCUtils.execute(DatabaseManager.Q_DELETE_COUPON_PURCHASE_BY_CUSTOMER, map);
    }
    @Override
    public void deleteCompanyCouponPurchase(int companyId) throws SQLException, InterruptedException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        JDBCUtils.execute(DatabaseManager.Q_DELETE_COMPANY_COUPON_PURCHASE, map);
    }

    @Override
    public boolean isExistCouponPurchasedByCustomer(int customerId, int couponId) throws SQLException {
        boolean isExist = false;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);
        map.put(2, customerId);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_IS_Exist_Coupon_Purchased_By_CUSTOMER, map);
        for (Object row : res) {
            isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;  }
        return isExist;
    }
//    @Override
//    public boolean isExistCouponPurchasedByCustomer(int customerId, int couponId) throws SQLException, InterruptedException {
//        boolean isExist = false;
//        Map<Integer, Object> map = new HashMap<>();
//        map.put(1, customerId);
//        map.put(2, couponId);
//        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_IS_Exist_Coupon_Purchased_By_Customer, map);
//        for (Object row : res) {
//            isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
//            break;  }
//        return isExist;
//    }


    @Override
    public void deleteCouponPurchaseById(int couponId) throws SQLException, InterruptedException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);
        JDBCUtils.execute(DatabaseManager.Q_DELETE_COUPON_PURCHASED_BY_COUPON_ID, map);
            }

    @Override
    public void deleteAllCustomerCouponsPurshase(int customerId) throws SQLException, InterruptedException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerId);
        JDBCUtils.execute(DatabaseManager.Q_DELETE_CUSTOMER_COUPONS, map);
    }


}
