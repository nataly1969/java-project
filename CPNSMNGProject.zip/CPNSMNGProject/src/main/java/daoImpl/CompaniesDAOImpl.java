package daoImpl;
import beans.Company;
import dao.CompaniesDAO;
import db.DatabaseManager;
import db.JDBCUtils;
import db.ResultUtils;

import java.sql.SQLException;
import java.util.*;

public class CompaniesDAOImpl implements CompaniesDAO {

    @Override
    public void addCompany(Company company) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, company.getName());
        map.put(2, company.getEmail());
        map.put(3, company.getPassword());
        JDBCUtils.execute(DatabaseManager.QUERY_INSERT_CMP, map);
    }

    @Override
    public void updateCompany(Company company) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, company.getEmail());
        map.put(2, company.getPassword());
        map.put(3, company.getId());
        JDBCUtils.execute(DatabaseManager.QUERY_UPDATE_CMP, map);
    }

    @Override
    public void deleteCompany(int Id) throws SQLException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1,Id);
        JDBCUtils.execute(DatabaseManager.QUERY_DELETE_CMP, map);
    }

    @Override
    public List<Company> getAllCompanies() throws SQLException {
        List<Company> companies = new ArrayList<>();
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_ALL_Companies);
        for (Object row : res) {
            companies.add( ResultUtils.fromHashMapToCompany((HashMap<Integer, Object>) row));
        }
        return companies;}


    @Override
    public Company getOneCompany(int Id) throws SQLException {
        Company company = null;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1,Id);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_SELECT_BY_ID_CMP,map);
        for (Object row : res) {
            company = (ResultUtils.fromHashMapToCompany((HashMap<Integer, Object>) row));
            break;}
        return company;    }

       @Override
    public Company getCompanyByEmailPassword(String email, String password) throws SQLException, InterruptedException {
        Company company = null;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1,email);
        map.put(2,password);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_SELECT_CMP_BY_EMAIL_PASSWORD,map);
        for (Object row : res) {
            company = (ResultUtils.fromHashMapToCompany((HashMap<Integer, Object>) row));
            break;}
        return company;    }

    @Override
    public boolean isCompanyExistById(int Id) throws SQLException {
        boolean isExist = false;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, Id);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_IS_EXIST_COMPANY_BY_ID, map);
        for (Object row : res) {
            isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;  }
        return isExist;  }
    @Override
    public boolean isCompanyExistByEmail(String email) throws SQLException, InterruptedException {
        boolean isExist = false;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, email);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_IS_EXIST_COMPANY_BY_MAIL, map);
        for (Object row : res) {
            isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;  }
        return isExist;
    }

    @Override
    public boolean isCompanyExistByName(String name) throws SQLException, InterruptedException {
        boolean isExist = false;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, name);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_IS_EXIST_COMPANY_BY_NAME, map);
        for (Object row : res) {
            isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;  }
        return isExist;
    }

    @Override
    public boolean isCompanyExist(String email, String password) throws SQLException {
        boolean isExist = false;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, email);
        map.put(2, password );

        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_IS_EXIST_COMPANY, map);
        for (Object row : res) {
            isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;  }
        return isExist;
    }


}



