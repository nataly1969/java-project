package daoImpl;

import beans.Category;
import beans.Coupon;
import dao.CouponsDAO;
import db.DatabaseManager;
import db.JDBCUtils;
import db.ResultUtils;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CouponsDAOImpl implements CouponsDAO {

    //private int customerId;

    @Override
    public void addCoupon(Coupon coupon) throws SQLException, InterruptedException {
        Map<Integer, Object> map = new HashMap<>();

        map.put(1, coupon.getCompanyId());
        map.put(2, coupon.getCategory().getIdValue());
        map.put(3, coupon.getTitle());
        map.put(4, coupon.getDescription());
        map.put(5, coupon.getStartDate());
        map.put(6, coupon.getEndDate());
        map.put(7, coupon.getAmount());
        map.put(8, coupon.getPrice());
        map.put(9, coupon.getImage());
        JDBCUtils.execute(DatabaseManager.QUERY_INSERT_COUPON, map);
    }
    @Override
    public void updateCoupon(Coupon coupon) throws SQLException, InterruptedException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, coupon.getCategory().getIdValue());
        map.put(2, coupon.getTitle());
        map.put(3, coupon.getDescription());
        map.put(4, coupon.getStartDate());
        map.put(5, coupon.getEndDate());
        map.put(6, coupon.getAmount());
        map.put(7, coupon.getPrice());
        map.put(8, coupon.getImage());
        map.put(9, coupon.getId());
        JDBCUtils.execute(DatabaseManager.Q_UPDATE_COUPON, map);
    }

    @Override
    public void deleteCoupon(int couponId) throws SQLException, InterruptedException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);
        JDBCUtils.execute(DatabaseManager.Q_DELETE_COUPON_BY_ID, map);

    }
      @Override
    public List<Coupon> getAllCoupons() throws SQLException {
        List<Coupon> coupons = new ArrayList<>();
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_ALL_COUPONS);
        for (Object row : res) {
            coupons.add( ResultUtils.fromHashMapToCoupon((HashMap<Integer, Object>) row));
        }
        return coupons;
    }
    @Override
    public List<Coupon> getAllCouponsExpiredDate() throws SQLException, InterruptedException  {
        List<Coupon> coupons = new ArrayList<>();
        System.out.println(LocalDate.now() +  "in IMPL DEBUG");
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_ALL_COUPONS_EXPIRED_DATE);
        for (Object row : res) {
            coupons.add( ResultUtils.fromHashMapToCoupon((HashMap<Integer, Object>) row));
        }
        return coupons;
    }
     @Override
    public List<Coupon> getAllCustomerCoupons(int customerId) throws SQLException {
        List<Coupon> coupons = new ArrayList<>();
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerId);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_All_Customer_Coupons, map);
        for (Object row : res) {
            coupons.add( ResultUtils.fromHashMapToCoupon((HashMap<Integer, Object>) row));
        }
        return coupons;
    }

    @Override
    public List<Coupon> getAllCompanyCouponsByUnderPrice(int companyId,double price) throws SQLException {
        List<Coupon> coupons = new ArrayList<>();
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        map.put(2, price);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_ALL_COMPANY_COUPONS_UNDER_PRICE, map);
        for (Object row : res) {
            coupons.add( ResultUtils.fromHashMapToCoupon((HashMap<Integer, Object>) row));
        }
        return coupons;
    }
    @Override
    public List<Coupon> getAllCustomerCouponsUnderPrice(int customerId, double price) throws SQLException {
        List<Coupon> coupons = new ArrayList<>();
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, price);
        map.put(2, customerId);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_ALL_CUSTOMER_COUPONS_UNDER_PRICE, map);
        for (Object row : res) {
            coupons.add( ResultUtils.fromHashMapToCoupon((HashMap<Integer, Object>) row));
        }
        return coupons;
    }
    @Override
    public List<Coupon> getAllCompanyCouponsByCategory(int companyId, Category category) throws SQLException {
        List<Coupon> coupons = new ArrayList<>();
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        map.put(2, category.getIdValue());
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_SELECT_ALL_COMPANY_COUPONS_CATEG, map);
        for (Object row : res) {
            coupons.add( ResultUtils.fromHashMapToCoupon((HashMap<Integer, Object>) row));
        }
        return coupons;
    }

    @Override
    public List<Coupon> getAllCustomerCouponsByCategory(int customerId, Category category) throws SQLException {
        List<Coupon> coupons = new ArrayList<>();
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, category.getIdValue());
        map.put(2, customerId);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_SELECT_ALL_CUSTOMER_COUPONS_CATEG, map);
        for (Object row : res) {
            coupons.add( ResultUtils.fromHashMapToCoupon((HashMap<Integer, Object>) row));
        }
        return coupons;
    }
    @Override
    public List<Coupon> getAllCompanyCoupons(int companyId) throws SQLException {
        List<Coupon> coupons = new ArrayList<>();
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_SELECT_ALL_COMPANY_COUPONS, map);
        for (Object row : res) {
            coupons.add( ResultUtils.fromHashMapToCoupon((HashMap<Integer, Object>) row));
        }
        return coupons;
    }
    @Override
    public boolean isExistCouponInStock(int couponId) throws SQLException, InterruptedException {
        boolean isExist = false;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_IS_EXIST_COUPON_IN_STOCK, map);
        for (Object row : res) {
            isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;  }
        return isExist;
    }
    @Override
    public boolean isExistCouponOfCompanyCategory(int couponId, int companyId, Category category) throws SQLException, InterruptedException {
        boolean isExist = false;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);
        map.put(2, companyId);
        map.put(3, category.getIdValue());
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_IS_EXIST_CPN_BY_FULL_KEY, map);
        for (Object row : res) {
            isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;  }
        return isExist;
    }

   @Override
    public Coupon getOneCouponOfCompanyByTitle(int companyId , String title) throws SQLException, InterruptedException {
        Coupon coupon  = null;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        map.put(2, title);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_ONE_COMPANY_COUPON_BY_TITLE, map);
        for (Object row : res) {
            coupon = (ResultUtils.fromHashMapToCoupon((HashMap<Integer, Object>) row));
            break;}
        return coupon;

    };
    //todo  check  where used !!!
    @Override
    public Coupon getOneCouponOfCompanyCategory(int couponId,int companyId,Category category) throws SQLException, InterruptedException {
        Coupon coupon  = null;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);
        map.put(2, companyId);
        map.put(3, category.getIdValue());
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_CPN_BY_ID_COMPANY_CATEGORY, map);
        for (Object row : res) {
            coupon = (ResultUtils.fromHashMapToCoupon((HashMap<Integer, Object>) row));
            break;}
        return coupon;
    }

    @Override
    public Coupon getOneCouponById(int couponId) throws SQLException, InterruptedException {
        Coupon coupon  = null;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_SELECT_COUPON_BY_ID, map);
        for (Object row : res) {
            coupon = (ResultUtils.fromHashMapToCoupon((HashMap<Integer, Object>) row));
            break;}
        return coupon;
    }
    @Override
    public boolean isCouponExist(int couponId) throws SQLException, InterruptedException {
        boolean isExist = false;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_IS_EXIST_COUPON, map);
        for (Object row : res) {
            isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;  }
        return isExist;
    }
    @Override
    public void deleteCompanyCoupons(int companyId) throws SQLException, InterruptedException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);

        JDBCUtils.execute(DatabaseManager.Q_DELETE_COMPANY_COUPONS, map);
    }

    @Override
    public boolean isExistsCompanyCouponByTitle(int companyId,String title) throws SQLException, InterruptedException {
        boolean isExist = false;
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        map.put(2, title);
        List<?> res = JDBCUtils.executeResults(DatabaseManager.Q_IS_EXIST_COMPANY_COUPON_BY_TITLE, map);
        for (Object row : res) {
            isExist = ResultUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;
        }
        return isExist;
    }

    @Override
    public void reduceAmountOfOnePurchasedCoupon(int couponId) throws SQLException, InterruptedException {
            Map<Integer, Object> map = new HashMap<>();
            map.put(1, couponId);
            JDBCUtils.execute(DatabaseManager.Q_UPDATE_AMOUNT_PURSHACED_CUSTOMER_COUPONS, map);

    }


}
