package utils;

import java.time.LocalDate;

public class dataUtils {
    public static String format(LocalDate date) {
        int day = date.getDayOfMonth();
        int month = date.getMonthValue();
        int year = date.getYear();
        return String.format("%04d" + "-" +"/%02" + "_" + "/%02",year, month, day);
    }
}
