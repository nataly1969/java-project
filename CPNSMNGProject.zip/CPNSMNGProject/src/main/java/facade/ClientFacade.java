package facade;

import dao.CompaniesDAO;
import dao.CouponsDAO;
import dao.CustomersDAO;
import dao.CustomersVsCouponsDAO;
import daoImpl.CompaniesDAOImpl;
import daoImpl.CouponsDAOImpl;
import daoImpl.CustomersDAOImpl;
import daoImpl.CustomersVsCouponsDAOImpl;

import java.sql.SQLException;

public abstract class ClientFacade {
    protected CompaniesDAO companiesDAO = new CompaniesDAOImpl();
    protected CustomersDAO customersDAO = new CustomersDAOImpl();
    protected CouponsDAO couponsDAO = new CouponsDAOImpl();
    protected CustomersVsCouponsDAO customersVsCouponsDAO  = new CustomersVsCouponsDAOImpl();

    public abstract boolean login(String email,String password) throws SQLException,InterruptedException;
}
