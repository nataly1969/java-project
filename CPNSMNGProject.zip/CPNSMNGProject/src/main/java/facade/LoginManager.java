package facade;

import beans.ClientType;
import utils.Art;

public class LoginManager {
    //     step1 : create a single ref here
    private static LoginManager instance = new LoginManager();

    //   Step 2 : private CTOR
    private LoginManager(){}

    //    step3 :  expose static get
    public static LoginManager getInstance() {
        return instance;
    }


    public ClientFacade login(String email, String password, ClientType clientType) throws Exception {
        System.out.println("LoginManager ClientType  is = " +  clientType + " " + email + " " + password);
        ClientFacade facade = null;
        boolean isLoginRight;
        switch (clientType) {
            case Administrator: {
               if (email == "admin@admin.com" & password == "admin") {
                    System.out.println(Art.ADMIN_FACADE);
                    facade = new AdminFacade();
                } else {
                    System.out.println(" LoginManager :  You are not authorized to use Administrator Facade! ");
                }
                break;
            }
            case Company:
                facade = new CompanyFacade();
                if (!facade.login(email, password)) {
                    System.out.println(" LoginManager : You are not authorized to use Companies Facade!  ");
                    facade = null;
                }
                break;

            case Customer:
                facade = new CustomerFacade();
                if (!facade.login(email, password)) {
                    System.out.println(" LoginManager : You are not authorized to use Customer Facade!  ");
                    facade = null;
                }
                break;
            default:
                System.out.println(" LoginManager You are not authorized to use the < Coupons_Management system! ");
        }
        return facade;
    }

    ;
}