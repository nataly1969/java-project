package facade;

import beans.Category;
import beans.Company;
import beans.Coupon;
import utils.Art;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CompanyFacade extends ClientFacade {
    private static int companyId = 0;

    public CompanyFacade() {
        System.out.println(Art.COMPANY);}

    @Override
    public boolean login(String email, String password) throws SQLException, InterruptedException {
        boolean isExists = false;
        if (companiesDAO.isCompanyExist(email, password)) {
            isExists = true;
            Company company = companiesDAO.getCompanyByEmailPassword(email, password);
            /* initialize  static variable of companyFacade */
            CompanyFacade.companyId = company.getId();
        }
        return isExists;
    }

    public static int getCompanyId() {
        return companyId;
    }

    public List<Coupon> getCompanyCoupons() throws Exception {
        List<Coupon> coupons = new ArrayList<>();
        coupons = couponsDAO.getAllCompanyCoupons(CompanyFacade.companyId);
        return coupons;
    }

     public Company getCompanyDetails() throws Exception {
        Company company = new Company();
        if (companiesDAO.isCompanyExistById(CompanyFacade.companyId)) {
            company = companiesDAO.getOneCompany(CompanyFacade.companyId);
             }
        return company;
    }

   // public Company getCompanyNameByEmailPass(String email, String password) throws Exception {
//        Company company = new Company();
//        if (companiesDAO.isCompanyExist(email, password)) {
//            company = companiesDAO.getCompanyByEmailPassword(email, password);
//             }
//        return company;
//    }

    public Coupon getOneCompanyCouponByTitle(int companyId, String title) throws Exception {
        Coupon coupon = new Coupon();
        coupon = couponsDAO.getOneCouponOfCompanyByTitle(companyId, title);
        return coupon;
    }

    public List<Coupon> getCompanyCouponsByCategory(Category category) throws Exception {
        // if (companiesDAO.isCompanyExistById(companyId)) {}
        List<Coupon> coupons = new ArrayList<>();
        coupons = couponsDAO.getAllCompanyCouponsByCategory(CompanyFacade.companyId, category);
        return coupons;
    }

    public List<Coupon> getCompanyCouponsUnderPrice(double price) throws Exception {
        // if (companiesDAO.isCompanyExistById(companyId)) {}
        List<Coupon> coupons = new ArrayList<>();
        coupons = couponsDAO.getAllCompanyCouponsByUnderPrice(CompanyFacade.companyId, price);
        return coupons;
    }

    public void addCoupon(Coupon coupon) throws Exception {
        if (CompanyFacade.companyId != coupon.getCompanyId()) {
            System.out.println("        CompanyFacade.addCoupon:  company of coupon is wrong " + coupon.getCompanyId());
        } else if (!companiesDAO.isCompanyExistById(CompanyFacade.companyId)) {
            System.out.println("        CompanyFacade.addCoupon:   Company of coupon in not exist ");
        } else if (couponsDAO.isExistsCompanyCouponByTitle(coupon.getCompanyId(), coupon.getTitle())) {
            System.out.println("        CompanyFacade.addCoupon:  This coupon already exist by Title " + coupon.getTitle());
        } else {
            try {
                couponsDAO.addCoupon(coupon);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
            System.out.println("\"        CompanyFacade.addCoupon:    new coupon added successfully! ");
        }
    }

    public void updateCoupon(Coupon coupon) throws Exception {
        if (CompanyFacade.companyId != coupon.getCompanyId()) {
            System.out.println("        CompanyFacade.updateCoupon:  company of coupon is wrong " + coupon.getCompanyId());
        } else if (!couponsDAO.isExistsCompanyCouponByTitle(coupon.getCompanyId(), coupon.getTitle())) {
            System.out.println("          CompanyFacade.updateCoupon: coupon not exists:" + coupon);
        } else {
            Coupon fetchedCoupon = couponsDAO.getOneCouponOfCompanyByTitle(coupon.getCompanyId(), coupon.getTitle());
             System.out.println("  debug fetched coupon " + fetchedCoupon);
             System.out.println("  debug updates coupon " + coupon);
             if (fetchedCoupon.getCategory() == coupon.getCategory())
             //       & (fetchedCoupon.getTitle() == coupon.getTitle()))
            {
            try {
                System.out.println("upd in progress");
                coupon.setTitle(fetchedCoupon.getTitle());
                couponsDAO.updateCoupon(coupon);
                System.out.println("\"        CompanyFacade.updateCoupon:    new coupon updated successfully! ");
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }}
         else {
                System.out.println("        CompanyFacade.updateCoupon:  Don't  change Title and Category og coupon");}
        }
    }
    public void deleteCoupon(int couponId) throws Exception {
        if (couponsDAO.isCouponExist(couponId)) {
            Coupon coupon = couponsDAO.getOneCouponById(couponId);
            if (CompanyFacade.companyId != coupon.getCompanyId()) {
                System.out.println("        CompanyFacade.deleteCoupon:  company " +
                        CompanyFacade.companyId + " not autorized to delete coupons of company " + coupon.getCompanyId());
                return;
            }
                try {
                    customersVsCouponsDAO.deleteCouponPurchaseById(couponId);
                    couponsDAO.deleteCoupon(couponId);
                } catch (Exception e) {
                    System.err.println(e.getMessage());
                }
                return;
        }
    }
//  ------------------------       e n d   f a c a d e         ---------------------
    }




