package facade;

import beans.Company;
import beans.Customer;

import java.util.ArrayList;
import java.util.List;

public class AdminFacade extends ClientFacade {

    public AdminFacade() {
    }

    @Override
    public boolean login(String email, String password) {
        return (email == "admin@admin.com" & password == "admin");
    }

    /* --------------------------  get  One -------------------------------------------- */
    public Company getOneCompany(int id) throws Exception {
        Company company = new Company();
        company = companiesDAO.getOneCompany(id);
        return company;
    }

    public Customer getOneCustomer(int id) throws Exception {
        Customer customer = new Customer();
        customer = customersDAO.getOneCustomer(id);
        return customer;
    }

    /* --------------------------get all -------------------------------- */
    public List<Company> getAllCompanies() throws Exception {
        List<Company> companies = new ArrayList<>();
        companies = companiesDAO.getAllCompanies();
        return companies;
    }

    public List<Customer> getAllCustomers() throws Exception {
        List<Customer> customers = new ArrayList<>();
        customers = customersDAO.getAllCustomers();
        return customers;
    }

    /* ------------   add / delete ------------------------------------ */
    public void addCompany(Company company) throws Exception {
        if (companiesDAO.isCompanyExistByName(company.getName()) ||
                companiesDAO.isCompanyExistByEmail(company.getEmail())) {
            System.out.println("This Company allrady exists!");
        } else {
            try {
                companiesDAO.addCompany(company);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }

    public void updateCompany(Company company) throws Exception {
        if (companiesDAO.isCompanyExistById(company.getId())) {
//            בדיקה האם לקוח קיים בבסיס נתונים ושליפת שורה
            Company fetchedCompany = companiesDAO.getOneCompany(company.getId());

            fetchedCompany.setEmail(company.getEmail());
            fetchedCompany.setPassword(company.getPassword());
            try {
                companiesDAO.updateCompany(fetchedCompany);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }

    public void deleteCompany(Company company) throws Exception {
        if (companiesDAO.isCompanyExistById(company.getId())) {
            try {
                customersVsCouponsDAO.deleteAllCustomerCouponsPurshase(company.getId());
                couponsDAO.deleteCompanyCoupons(company.getId());
                companiesDAO.deleteCompany(company.getId());
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }

    //--------------------   customers -------------------------------
    public void addCustomer(Customer customer) throws Exception {
        if (customersDAO.isCustomerExistByEmail(customer.getEmail())) {
            System.out.println("This Customer allrady exists!");
        } else {
            try {
                customersDAO.addCustomer(customer);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }

    public void deleteCustomer(int customerId) throws Exception {
        if (customersDAO.isCustomerExistById(customerId)) {
            try {
                customersVsCouponsDAO.deleteAllCustomerCouponsPurshase(customerId);
                customersDAO.deleteCustomer(customerId);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }


    /* -------------------------- Update  -------------------------------- */
    public void updateCustomer(Customer customer) throws Exception {
        if (customersDAO.isCustomerExistById(customer.getId())) {
            //בדיקה האם לקוח קיים בבסיס נתונים ושליפת שורה
            Customer fetchedCustomer = customersDAO.getOneCustomer(customer.getId());

            fetchedCustomer.setEmail(customer.getEmail());
            fetchedCustomer.setPassword(customer.getPassword());
            fetchedCustomer.setFirstName(customer.getFirstName());
            fetchedCustomer.setLastName(customer.getLastName());

            try {
                customersDAO.updateCustomer(fetchedCustomer);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }

    public void updateCustomerNameByEmailPass(Customer customer) throws Exception {
        if (customersDAO.isCustomerExist(customer.getEmail(), customer.getPassword())) {
            //בדיקה האם לקוח קיים בבסיס נתונים ושליפת שורה
            Customer fetchedCustomer = customersDAO.getCustomerByEmailPass(customer.getEmail(), customer.getPassword());
            fetchedCustomer.setFirstName(customer.getFirstName());
            fetchedCustomer.setLastName(customer.getLastName());
            try {
                customersDAO.updateCustomer(customer);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }


}
