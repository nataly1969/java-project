package facade;

import Exceptions.SystemException;
import beans.Category;
import beans.Coupon;
import beans.Customer;
import utils.Art;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerFacade extends ClientFacade {
    public CustomerFacade() {
        System.out.println(Art.CUSTOMER);
    }

    private static int customerId = 0;

    @Override
    public boolean login(String email, String password) throws SQLException, InterruptedException {
        boolean isExists = false;
        if (customersDAO.isCustomerExist(email, password)) {
            isExists = true;
            Customer customer = customersDAO.getCustomerByEmailPass(email, password);
            /* initialize  static variable of companyFacade */
            CustomerFacade.customerId = customer.getId();
        }
        return isExists;
    }

    public Customer getCustomerDetails() throws SystemException {
        try {
            return customersDAO.getOneCustomer(CustomerFacade.customerId);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return null;
    }
    public Customer getCustomerDetilsByEmailPass(String email, String password) throws Exception {
        Customer customer = new Customer();
        if (customersDAO.isCustomerExist(email, password)) {
            customer = customersDAO.getCustomerByEmailPass(email, password);
            CustomerFacade.customerId = customer.getId();
        }
        return customer;
    }
    public List<Coupon> getCustomerCoupons() throws SystemException {
        List<Coupon> coupons = new ArrayList<>();
        try {
            coupons = couponsDAO.getAllCustomerCoupons(CustomerFacade.customerId);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return coupons;
    }

    public List<Coupon> getCustomerCouponsUnderPrice(double price) throws Exception {
        List<Coupon> coupons = new ArrayList<>();
        coupons = couponsDAO.getAllCustomerCouponsUnderPrice(CustomerFacade.customerId, price);
        return coupons;
    }

    public List<Coupon> getCustomerCouponsByCategory(Category category) throws Exception {
        List<Coupon> coupons = new ArrayList<>();
        coupons = couponsDAO.getAllCustomerCouponsByCategory(CustomerFacade.customerId, category);
        return coupons;
    }


    public void purchaseCoupon(Coupon coupon) throws Exception {
        if (!customersDAO.isCustomerExistById(CustomerFacade.customerId)) {
            System.out.println("        purchaseCoupon:  Customer is wrong : " + CustomerFacade.customerId);
            return;
        } else if (customersVsCouponsDAO.isExistCouponPurchasedByCustomer(CustomerFacade.customerId, coupon.getId())) {
            System.out.println("        purchaseCoupon:  Coupon \"" + coupon.getTitle() + "\" already purchased by customer : " + CustomerFacade.customerId);
            return;
        } else if (!couponsDAO.isExistCouponInStock(coupon.getId())) {
            System.out.println("        purchaseCoupon:  Coupon " + "\"" + coupon.getTitle() + "\" not in stock(amount=0 or date expired) :  " + coupon);
            return;
        }
        try {
            couponsDAO.reduceAmountOfOnePurchasedCoupon(coupon.getId());
            customersVsCouponsDAO.addCouponPurchase(CustomerFacade.customerId, coupon.getId());
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return;
    }



    //  ----------------e n d      customer   facade ----------------------------------------------
}

