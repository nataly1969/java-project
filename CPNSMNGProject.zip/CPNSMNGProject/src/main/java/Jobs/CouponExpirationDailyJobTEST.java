package Jobs;

import beans.Coupon;
import dao.CouponsDAO;
import dao.CustomersVsCouponsDAO;
import daoImpl.CouponsDAOImpl;
import daoImpl.CustomersVsCouponsDAOImpl;

import java.util.List;

public class CouponExpirationDailyJobTEST implements Runnable {
    private CouponsDAO couponsDAO = new CouponsDAOImpl();
    private CustomersVsCouponsDAO customersVsCouponsDAO = new CustomersVsCouponsDAOImpl();
    private boolean exitJob;

//    public static void CouponExpirationDailyJob() {
//    }

    public CouponExpirationDailyJobTEST() {
    }

    public void setExitJob(boolean exitJob) {
        this.exitJob = exitJob;
    }


    @Override
    public void run() {
        while (exitJob) {
            CouponExpirationDailyJobTEST(couponsDAO, customersVsCouponsDAO, exitJob);
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            return;
        }
    }


    public void CouponExpirationDailyJobTEST(CouponsDAO couponsDAO, CustomersVsCouponsDAO customersVsCouponsDAO, boolean quit) {
        this.couponsDAO = couponsDAO;
        this.customersVsCouponsDAO = customersVsCouponsDAO;
        this.exitJob = quit;
        System.out.println("START RUN DAILY JOB = CouponExpirationDailyJob");
        List<Coupon> coupons = null;
        try {
            coupons = couponsDAO.getAllCouponsExpiredDate();
            System.out.println(coupons.size() + " coupons will be deleted now ");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

        for (Coupon coupon : coupons) {
            System.out.println("start for each ONE coupon");
            System.out.println("Coupon " + coupon + " begin function deleteCoupon");
            try {
                customersVsCouponsDAO.deleteCouponPurchaseById(coupon.getId());
                couponsDAO.deleteCoupon(coupon.getId());
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }
        /*  -----------------          END    CLASS           ------------------  */

}