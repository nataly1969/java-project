package Jobs;

import beans.Coupon;
import dao.CouponsDAO;
import dao.CustomersVsCouponsDAO;
import daoImpl.CouponsDAOImpl;
import daoImpl.CustomersVsCouponsDAOImpl;
import utils.Art;
import utils.TablePrinter;

import java.util.List;

public class CouponExpirationDailyJob implements Runnable {
    private CouponsDAO couponsDAO = new CouponsDAOImpl();
    private CustomersVsCouponsDAO customersVsCouponsDAO = new CustomersVsCouponsDAOImpl();
    private boolean exitJob;

    public CouponExpirationDailyJob() {}
    public void setExitJob(boolean exitJob) {
        this.exitJob = exitJob;
    }

    @Override
    public void run() {
        while (exitJob) {
            CouponExpirationDailyJob(couponsDAO, customersVsCouponsDAO, exitJob);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return;
        }
    }

    public void CouponExpirationDailyJob(CouponsDAO couponsDAO, CustomersVsCouponsDAO customersVsCouponsDAO, boolean quit) {
        System.out.println(Art.START_JOB);
        List<Coupon> coupons = null;
        try {
            System.out.println(Art.COUPONS_BEFORE);
            TablePrinter.print(couponsDAO.getAllCoupons());
            coupons = couponsDAO.getAllCouponsExpiredDate();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        for (Coupon coupon : coupons) {
            try {
                customersVsCouponsDAO.deleteCouponPurchaseById(coupon.getId());
                couponsDAO.deleteCoupon(coupon.getId());

            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
        System.out.println(Art.COUPONS_AFTER);
        try {
        TablePrinter.print(couponsDAO.getAllCoupons());
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        System.out.println(Art.END_JOB);
    }
    /*  -----------------          END    CLASS           ------------------  */

}