import Jobs.CouponExpirationDailyJob;
import db.ConnectionPool;
import db.DatabaseManager;
import utils.Art;

import static db.AddDataToDataBase.*;


public class Program {
       public static void main(String[] args) throws Exception {

              ConnectionPool.getInstance().openAllConnections();
              try {
                     DatabaseManager.databaseStrategy();
                     FillCompaniesTable();
                     FillCustomersTable();
                     FillCategoriesTable();
                     FillCouponsTable();
                     FillCustomersVsCouponsTable();

              } catch (Exception e) {
                     System.out.println(e.getMessage());
              }

              test.testAll();

              CouponExpirationDailyJob couponExpirationDailyJob = new CouponExpirationDailyJob();
              couponExpirationDailyJob.setExitJob(true);
              Thread t1 = new Thread(couponExpirationDailyJob);
              t1.start();
              t1.join();
               /* THIS LAMBDA will not be applied>>  new Thread(() ->  new CouponExpirationDailyJob()).start();*/
              couponExpirationDailyJob.setExitJob(false);
              ConnectionPool.getInstance().closeAllConnections();
              System.out.println(Art.END_PROJECT);





              /*   ------------------     END   of  PROGRAM  -----------------*/

       }

}

